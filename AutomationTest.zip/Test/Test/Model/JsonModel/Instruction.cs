﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Model.JsonModel
{
    public class Instruction
    {
        public string instructionRef { get; set; }
        public string customerRef { get; set; }
        public string direction { get; set; }
        public string financialInstrumentId { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
        public string country { get; set; }
        public string settledByDate { get; set; }
        public string schemeId { get; set; }
    }
}
