﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Model.JsonModel
{
    public class JsonRootObject
    {
        public string orderRef { get; set; }
        public List<Instruction> instructions { get; set; }
        public IDictionary<string,string> metadata  { get; set; }
        public object customerDefaults { get; set; }
    }
}
