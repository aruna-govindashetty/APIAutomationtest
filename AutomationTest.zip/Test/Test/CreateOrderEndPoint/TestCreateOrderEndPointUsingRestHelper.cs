﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Model.JsonModel;

namespace Test.CreateOrderEndPoint
{
    [TestClass]
    public class TestCreateOrderEndPointUsingRestHelper
    {
        private string postUrl = "https://sandbox-api.imbursepayments.com/v1/order-management";

        [TestMethod]
        public void TestPostWithModelObject()
        {
            IRestClient restClient = new RestClient();
            IRestRequest request = new RestRequest()
            {
                Resource = postUrl
            };
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/xml");
            request.AddHeader("AccountId", "782f1b71-7ca4-4465-917f-68d58ffbec8b");
            request.AddHeader("TenantId", "1b651a36-07b2-45d3-ae4f-ce7df8f906bd");
            request.RequestFormat = DataFormat.Json;
           //request.AddJsonBody(GetOrderObject());
            IRestResponse restResponse = restClient.Post(request);
            Assert.AreEqual(200, (int)restResponse.StatusCode);
            Console.WriteLine(restResponse.Content);
        }
    }
}
