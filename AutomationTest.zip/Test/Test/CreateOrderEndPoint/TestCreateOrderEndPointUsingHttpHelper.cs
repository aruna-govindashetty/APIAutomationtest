﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Test.Helper;
using Test.Helper.Authentication.HMAC;
using Test.Helper.Request;
using Test.Model;
using Test.Model.JsonModel;

namespace Test.CreateOrderEndPoint
{
    [TestClass]
    public class TestCreateOrderEndPointUsingHttpHelper
    {
        private string Url = "https://sandbox-api.imbursepayments.com/v1/order-management";
        private Model.RestResponse restResponse;
        private Model.RestResponse restResponseForGet;
        private string jsonMediaType = "application/json";

        [TestMethod]
        public void CreateOrderWithInstruction()
        {
            string orderRef = HttpClientHelper.RandomString(8);
            string instructionRef= HttpClientHelper.RandomString(8);
            string customerRef = HttpClientHelper.RandomString(8);

            string jsonData = "{" +
                                     "\"orderRef\": " + orderRef + "," +
                                     "\"instructions\": [" +
                                     "{," +
                                     "\"instructionRef\": " + instructionRef + "," +
                                     "\"customerRef\": " + customerRef + "," +
                                     "\"direction\": \"DEBIT\"," +
                                     "\"currency\": \"Euro\"," +
                                     "\"country\": \"Ireland\"," +
                                     "\"amount\": \"6.99\"," +
                                     "\"schemeId\": \"654EB81FF7F07F7CF5A1EE3FF6972E90\"," +
                                     "\"settledByDate\": \"2020-09-23\"," +
                                     "}," +
                                     "]" +
                                     "\"metadata\": {" +
                                     "\"Key\":  \"value\"," +
                                     "}," +
                                     "\"customerDefaults\": \"\"" +
                                     "}";

            GenerateBearerToken token = new GenerateBearerToken();
            string authHeader = token.GenerateAuthorizationToken();
            authHeader = "bearer " + authHeader;

            Dictionary<string, string> httpHeader = new Dictionary<string, string>();
            httpHeader.Add("Content-Type", "application/json");
            httpHeader.Add("Accept", "application/xml");
            httpHeader.Add("AccountId", "782f1b71-7ca4-4465-917f-68d58ffbec8b");
            httpHeader.Add("TenantId", "1b651a36-07b2-45d3-ae4f-ce7df8f906bd");

            restResponse = HttpClientHelper.PerformPostResquest(Url, jsonData, jsonMediaType, httpHeader);
            Assert.AreEqual(200, restResponse.StatusCode);
            Assert.IsNotNull(restResponse.ResponseData, "ResponseData is null");
        }

        [TestMethod]
        public void CreateInvalidOrder()
        {
            string orderRef = "^%$Test";

            string jsonData = "{" +
                                     "\"orderRef\": " + orderRef + "," +
                                     "\"instructions\": [" +
                                     "{," +
                                     "\"instructionRef\": \"TestInstReference\"," +
                                     "\"customerRef\": \"TestCustRef\"," +
                                     "\"direction\": \"DEBIT\"," +
                                     "\"currency\": \"Euro\"," +
                                     "\"country\": \"Ireland\"," +
                                     "\"amount\": \"6.99\"," +
                                     "\"schemeId\": \"654EB81FF7F07F7CF5A1EE3FF6972E90\"," +
                                     "\"settledByDate\": \"2020-09-23\"," +
                                     "}," +
                                     "]" +
                                     "\"metadata\": {" +
                                     "\"Key\":  \"value\"," +
                                     "}," +
                                     "\"customerDefaults\": \"\"" +
                                     "}";

            using (HttpClient httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Add("Content-Type", "application/json");
                httpClient.DefaultRequestHeaders.Add("Accept", "application/xml");
                httpClient.DefaultRequestHeaders.Add("AccountId", "782f1b71-7ca4-4465-917f-68d58ffbec8b");
                httpClient.DefaultRequestHeaders.Add("TenantId", "1b651a36-07b2-45d3-ae4f-ce7df8f906bd");
                HttpContent httpContent = new StringContent(jsonData, Encoding.UTF8, jsonMediaType);
                Task<HttpResponseMessage> postResponse = httpClient.PostAsync(Url, httpContent);
                HttpStatusCode statusCode = postResponse.Result.StatusCode;
                HttpContent responseContent = postResponse.Result.Content;
                string responseData = responseContent.ReadAsStringAsync().Result;

                restResponse = new Model.RestResponse((int)statusCode, responseData);

                Assert.AreEqual(200, restResponse.StatusCode);
                Assert.IsNotNull(restResponse.ResponseData, "ResponseData is null");

                Task<HttpResponseMessage> getResponse = httpClient.GetAsync(Url + orderRef);
                restResponseForGet = new Model.RestResponse((int)getResponse.Result.StatusCode,
                    getResponse.Result.Content.ReadAsStringAsync().Result);
                JsonRootObject jsonObject = JsonConvert.DeserializeObject<JsonRootObject>(restResponseForGet.ResponseData);

                Assert.AreEqual(orderRef, jsonObject.orderRef);
            }

        }

        [TestMethod]
        public void CreateOrderWithInvalidDebit()
        {
            string orderRef = HttpClientHelper.RandomString(8);
            string instructionRef = HttpClientHelper.RandomString(8);
            string customerRef = HttpClientHelper.RandomString(8);

            string jsonData = "{" +
                                     "\"orderRef\": " + orderRef + "," +
                                     "\"instructions\": [" +
                                     "{," +
                                     "\"instructionRef\": " + instructionRef + "," +
                                     "\"customerRef\": " + customerRef + "," +
                                     "\"direction\": \"CREDIT\"," +
                                     "\"currency\": \"Euro\"," +
                                     "\"country\": \"Ireland\"," +
                                     "\"amount\": \"6.99\"," +
                                     "\"schemeId\": \"654EB81FF7F07F7CF5A1EE3FF6972E90\"," +
                                     "\"settledByDate\": \"2020-09-23\"," +
                                     "}," +
                                     "]" +
                                     "\"metadata\": {" +
                                     "\"Key\":  \"value\"," +
                                     "}," +
                                     "\"customerDefaults\": \"\"" +
                                     "}";

            GenerateBearerToken token = new GenerateBearerToken();
            string authHeader = token.GenerateAuthorizationToken();
            authHeader = "bearer " + authHeader;

            Dictionary<string, string> httpHeader = new Dictionary<string, string>();
            httpHeader.Add("Content-Type", "application/json");
            httpHeader.Add("Accept", "application/xml");
            httpHeader.Add("AccountId", "782f1b71-7ca4-4465-917f-68d58ffbec8b");
            httpHeader.Add("TenantId", "1b651a36-07b2-45d3-ae4f-ce7df8f906bd");

            restResponse = HttpClientHelper.PerformPostResquest(Url, jsonData, jsonMediaType, httpHeader);
            Assert.AreEqual(400, restResponse.StatusCode);
            Assert.AreEqual(restResponse.ResponseData.Contains("Direction value is Invalid"),true);
        }
    }
}
