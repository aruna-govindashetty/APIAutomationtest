﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Test.Model;

namespace Test.Helper.Authentication.HMAC
{
    public class GenerateBearerToken
    {
        private string postUrl = "https://sandbox-api.imbursepayments.com/v1/identity/hmac";
        private RestSharp.RestResponse restResponse;

        public string GenerateAuthorizationToken()
        {
            GenerateHMAC hmacSign = new GenerateHMAC();
            IRestClient restClient = new RestClient();
            IRestRequest request = new RestRequest()
            {
                Resource = postUrl
            };
            string hmacSignature = hmacSign.GenerateHmacToken();
            string authToken = ($"hmac {hmacSign}");

            request.AddHeader("Authorization", authToken);
            IRestResponse restResponse = restClient.Post(request);
            Assert.AreEqual(200, (int)restResponse.StatusCode);

            return authToken;
        }
    }
}
